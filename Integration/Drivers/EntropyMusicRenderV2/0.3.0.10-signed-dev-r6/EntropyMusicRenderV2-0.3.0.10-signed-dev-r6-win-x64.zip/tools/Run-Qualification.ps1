param([Parameter(Mandatory=$true)][string]$Repository,[switch]$RunLive,[switch]$Stress,[string]$Output)
$ErrorActionPreference='Stop'
$package=Split-Path $PSScriptRoot -Parent
& (Join-Path $PSScriptRoot 'Run-Live-Acceptance.ps1') -Repository $Repository -Package $package -RunLive:$RunLive -Stress:$Stress -Output $Output
