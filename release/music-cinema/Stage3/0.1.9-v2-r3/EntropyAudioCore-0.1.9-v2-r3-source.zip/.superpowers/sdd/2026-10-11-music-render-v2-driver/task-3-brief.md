## Task 3: One stereo WaveRT endpoint with the tested timeline

**Files:** adapt `kernel/*`, INF/INX and speaker filter tables; add kernel bindings for the model and focused model adapter fixtures in `tests/ModelTests.cpp`.

**Interfaces:** existing WaveRT `SetState`, `SetWritePacket`, `GetPacketCount`, position and notification DDIs delegate to the tested model. `CaptureCommittedPacket(...)` snapshots only an OS-committed packet. `AdvanceTransfer(qpc)` advances one clock and eligibility; position queries/timers cannot create a second producer. Buffer allocation selects one explicit packet or position-driven owner.

- [ ] Add `KernelBindingsKeepPrefill` and `NoDualProducer`: RUN must not reset valid queued data; multiple position/timer calls must not duplicate raw output.
- [ ] Add `AllocationModeIsNotWasapiFlag`, `PositionDrivenReadOwnership` and `StopDuringPendingCommit`: validate the ownership invariant separately for both buffer paths and lifetime teardown. The latter test forbids freeing/reusing storage while a snapshot/read still references it.
- [ ] Run the focused model adapter tests and confirm failures before bindings exist.
- [ ] Adapt the sample to the new PnP/service/interface identities and one render stereo endpoint; exclude microphone/tone/file-saving/offload facilities from this product. Advertise only the twelve allowed formats and exact supported buffer/period bounds.
- [ ] Connect format/clock/commit/transfer/ring model to the DDIs, preserve pre-RUN snapshots, implement partial EOS and explicit underrun/loss diagnostics. Use nonpaged/pinned memory and short metadata synchronization; no heap/logging/filesystem or waits in the realtime path.
- [ ] Build x64 Release, rerun the model/adapter tests and source/package audits. Preserve actual driver errors/warnings; inspect INF endpoint count/format tables and SYS imports. Commit this uninstalled candidate.
- [ ] Record polling as unqualified until the live harness demonstrates actual ownership. A timer/position model passing offline cannot authorize RAW_IDENTITY for a prematurely read buffer.

