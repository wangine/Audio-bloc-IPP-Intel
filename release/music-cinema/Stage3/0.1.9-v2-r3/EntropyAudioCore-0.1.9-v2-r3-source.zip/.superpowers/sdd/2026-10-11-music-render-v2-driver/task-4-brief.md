## Task 4: Private bridge and raw Provider V2 compatible with frozen Core

**Files:** create `kernel/BridgeDevice.*`, `provider/*`, the DLL definition and `tests/ProviderTests.cpp`; extend `tests/BridgeTests.cpp`.

**Interfaces:** provider exports exactly `entropy_endpoint_provider_v2(uint32_t,EntropyProviderApiV2*)` using the unchanged published ABI. `BridgeClient::open(const DeviceIdentity&)`, `read(EntropyIngressPacketV2&,void*,uint32_t)`, `cancel()`, `close()` wrap private device I/O. `EndpointIdentity::resolve()` binds to the new interface/PnP instance, returning the associated Windows render endpoint identity. Private read is an ownership transfer after complete successful copy; small buffers do not consume a packet.

- [ ] Write `ProviderAbiExactRaw`: require the frozen ABI hash and all five struct sizes, MUSIC-only role, RAW_PCM capability, exact original container bytes, full format/GUID, nonzero sequence/generation and zero reserved fields.
- [ ] Write `ReadTooSmallDoesNotConsume`, `CloseCancelsPendingRead`, `SecondReaderRefused`, `WrongDeviceRejected` and `AccessModeDoesNotInventWasapiMode`; use a fake bridge with the same wire protocol and deliberately similar foreign endpoint names.
- [ ] Run the Provider/bridge suites; confirm the named failures before the corresponding implementation.
- [ ] Implement IOCTL validation, session ownership and cancel/close rundown; implement the Provider with no sample conversion. Reuse the Core's supported private-transport access convention while keeping packet.mode UNKNOWN unless authoritative information exists.
- [ ] Implement test-only observation of the exact bytes returned to Core, with a bounded capture queue and explicit audit overflow counter; no second bridge reader, production file I/O or DSP change.
- [ ] Run complete tests and load the DLL export/ABI in an isolated harness; verify no Qt/DSP dependency and commit. Do not copy into active Stage1 provider directories or restart Core.

