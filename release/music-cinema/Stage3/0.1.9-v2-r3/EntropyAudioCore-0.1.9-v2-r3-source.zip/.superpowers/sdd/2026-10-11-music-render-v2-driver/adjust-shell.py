from pathlib import Path
root=Path('Drivers/EntropyMusicRenderV2/kernel/shell')
def edit(name,fn):
    p=root/name;p.write_text(fn(p.read_text()),encoding='utf-8')
def body(text,sig,new):
    a=text.index('{',text.index(sig));b=a+1;depth=1
    while depth:
        if text[b]=='{':depth+=1
        elif text[b]=='}':depth-=1
        b+=1
    return text[:a]+'{\n'+new+'\n}'+text[b:]
edit('minipairs.h',lambda s:s.replace('L"EntropyMusicTopologyV2",','const_cast<PWSTR>(L"EntropyMusicTopologyV2"),').replace('L"EntropyMusicWaveV2",','const_cast<PWSTR>(L"EntropyMusicWaveV2"),'))
edit('adapter.cpp',lambda s:body(s,'InstallAllCaptureFilters(','''    PAGED_CODE();
    UNREFERENCED_PARAMETER(_pDeviceObject);
    UNREFERENCED_PARAMETER(_pIrp);
    UNREFERENCED_PARAMETER(_pAdapterCommon);
    return STATUS_SUCCESS;'''))
edit('common.cpp',lambda s:s.replace('    CAdapterCommon *p = new(PoolFlags, MINADAPTER_POOLTAG) CAdapterCommon(UnknownOuter);','    p = new(PoolFlags, MINADAPTER_POOLTAG) CAdapterCommon(UnknownOuter);').replace('    NTSTATUS ntStatus;\n\n    //\n    // Only one adapter instance','    NTSTATUS ntStatus;\n    CAdapterCommon* p=nullptr;\n\n    //\n    // Only one adapter instance'))
# Use a precise local replacement after inspecting the original declaration.
edit('common.cpp',lambda s:s.replace('    NTSTATUS ntStatus;\n\n    //\n    // Only one','    NTSTATUS ntStatus;\n    CAdapterCommon* p=nullptr;\n\n    //\n    // Only one'))
edit('minwavert.cpp',lambda s:s.replace('#include "micarraywavtable.h"',''))
edit('minwavert.cpp',lambda s:body(s,'CMiniportWaveRT::DataRangeIntersection', '''    PAGED_CODE();
    UNREFERENCED_PARAMETER(MyDataRange);
    if(PinId!=0 || !ClientDataRange || !ResultantFormatLength || ClientDataRange->FormatSize<sizeof(KSDATARANGE_AUDIO) ||
        !IsEqualGUID(ClientDataRange->MajorFormat,KSDATAFORMAT_TYPE_AUDIO) ||
        !IsEqualGUID(ClientDataRange->SubFormat,KSDATAFORMAT_SUBTYPE_PCM) ||
        !IsEqualGUID(ClientDataRange->Specifier,KSDATAFORMAT_SPECIFIER_WAVEFORMATEX))return STATUS_NO_MATCH;
    const auto range=reinterpret_cast<const KSDATARANGE_AUDIO*>(ClientDataRange);
    if(range->MaximumChannels<2)return STATUS_NO_MATCH;
    PKSDATAFORMAT_WAVEFORMATEXTENSIBLE formats=nullptr;
    const auto count=GetPinSupportedDeviceFormats(PinId,&formats);
    for(ULONG i=0;i<count;++i) {
        const auto& w=formats[i].WaveFormatExt.Format;
        if(w.nSamplesPerSec<range->MinimumSampleFrequency || w.nSamplesPerSec>range->MaximumSampleFrequency ||
            w.wBitsPerSample<range->MinimumBitsPerSample || w.wBitsPerSample>range->MaximumBitsPerSample)continue;
        *ResultantFormatLength=sizeof(KSDATAFORMAT_WAVEFORMATEXTENSIBLE);
        if(!OutputBufferLength)return STATUS_BUFFER_OVERFLOW;
        if(OutputBufferLength<*ResultantFormatLength)return STATUS_BUFFER_TOO_SMALL;
        if(!ResultantFormat)return STATUS_INVALID_PARAMETER;
        RtlCopyMemory(ResultantFormat,&formats[i],*ResultantFormatLength);return STATUS_SUCCESS;
    }
    return STATUS_NO_MATCH;'''))
