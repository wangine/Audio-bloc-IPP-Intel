## Task 1: Pin the source and establish a real kernel build

**Files:** create the upstream tree/manifest, import and build scripts, initial kernel project, user-mode CMake project and `tests/PackageTests.py` under the planned root.

**Interfaces:** `Import-Reference.ps1 -Commit <sha> -Destination <path>` verifies every imported Git blob. `Build-Kernel.ps1 -Configuration Release -Platform x64` produces a SYS and build report without installing it. The report states actual compiler/toolset/SDK/WDK and SHA256, not inferred compatibility.

- [ ] Write `test_upstream_manifest_exact_pin` and `test_build_has_no_deployment_side_effects`: reject a different reference SHA, absent license and scripts invoking install/boot/certificate mutation.
- [ ] Run `python Drivers/EntropyMusicRenderV2/tests/PackageTests.py --reference-only`; confirm a missing import/manifest fails.
- [ ] Import only the pinned sample and its required notices/shared build references, keeping a complete per-file manifest; create build scripts that locate the installed kernel toolset and capture its explicit paths.
- [ ] Build the uninstalled x64 reference shell using `Build-Kernel.ps1`; confirm actual SYS output and nonzero size/hash, retain warnings. If WDK integration is unavailable, preserve the report and continue only independent model work; do not install or silently downgrade a toolset.
- [ ] Run the manifest/non-deployment checks again and commit the independently buildable reference baseline. This build is not a MUSIC endpoint acceptance result.

