## Task 5: Controlled WASAPI/PCM acceptance harness and stereo diagnostics

**Files:** create `audit/*`, `tests/AuditTests.cpp`, `tools/Build-Audit.ps1`, report schema and an acceptance runner under the planned root.

**Interfaces:** `WasapiClient::run(const RunConfig&) -> RunReport` records requested WASAPI mode/servicing separately from observed WaveRT mode; requires the exact new endpoint identity. `PcmPattern::frame(uint64_t frameIndex,const PcmFormat&,uint8_t* output)` emits distinct L/R values. `PcmVerifier::compare(expected,actual) -> Comparison` accounts for every byte and frame. `StereoMetrics::accumulate(rawPacket)` computes windowed pre-SRC statistics in the audit tool only.

- [ ] Write `VerifierRejectsMissingFirstAndLastFrame`, `VerifierRejectsDuplicateAndReorderedFrame`, `VerifierChecksAllContainerBytes` and `IncompleteAuditCannotPass`; confirm failures with truncated/corrupted synthetic fixtures before verifier implementation.
- [ ] Write `StereoKnownMidSideAndPearson`: mono has zero Side, antiphase has zero Mid, DC-offset fixtures distinguish uncentered correlation from Pearson; zero RMS/variance produce explicit undefined values, not division artifacts.
- [ ] Write `HarnessRejectsPhysicalOrForeignEndpoint` and `InterruptedStopIsNotDrainPass`; test discovery and tail accounting offline before opening a real device.
- [ ] Implement Exclusive Event-Driven and Polling client paths, prefill before Start, exact format negotiation, complete transfer/read drain and configurable buffer periods/durations. Capture expected/emitted/raw-received bytes and actual clock/packet evidence. Unsupported cases and audit overflow cannot become PASS.
- [ ] Run offline harness/model/provider tests; commit the harness. No existing virtual endpoint or physical DAC is opened by default.
- [ ] Define a live runner for 12 formats × 2 servicing modes, initially 10 seconds per case, plus 30-minute continuous stress at PCM24/192 kHz with validated servicing. Record exact duration/frame coverage, not unlimited stability. Add per-format STOP/RUN, format-change, EOS/partial-tail and wrap cases; simulator ULONG wrap remains labeled offline.

