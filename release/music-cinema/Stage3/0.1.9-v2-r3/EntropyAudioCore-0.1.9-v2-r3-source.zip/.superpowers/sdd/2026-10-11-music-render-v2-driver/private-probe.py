import ctypes,struct
from ctypes import wintypes as w
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.CreateFileW.argtypes=[w.LPCWSTR,w.DWORD,w.DWORD,w.LPVOID,w.DWORD,w.DWORD,w.HANDLE];k.CreateFileW.restype=w.HANDLE
k.DeviceIoControl.argtypes=[w.HANDLE,w.DWORD,w.LPVOID,w.DWORD,w.LPVOID,w.DWORD,ctypes.POINTER(w.DWORD),w.LPVOID];k.DeviceIoControl.restype=w.BOOL
k.CloseHandle.argtypes=[w.HANDLE]
base=r'\\?\root#media#0003#{ab93289e-2692-47a9-bc47-ed1711f6e430}'+'\\'
for ref in ['entropymusicpcmv1','EntropyMusicPcmV1']:
 h=k.CreateFileW(base+ref,0xc0000000,3,None,3,0,None);err=ctypes.get_last_error()
 print(ref,'handle',h,'error',err)
 if h==w.HANDLE(-1).value:continue
 req=ctypes.create_string_buffer(struct.pack('<IIII',0x324d5045,0x10000,16,2));out=ctypes.create_string_buffer(256);n=w.DWORD()
 ok=k.DeviceIoControl(h,0x22e004,req,16,out,256,ctypes.byref(n),None)
 print('INFO',bool(ok),'error',ctypes.get_last_error(),'bytes',n.value,'header',out.raw[:32].hex())
 k.CloseHandle(h)

