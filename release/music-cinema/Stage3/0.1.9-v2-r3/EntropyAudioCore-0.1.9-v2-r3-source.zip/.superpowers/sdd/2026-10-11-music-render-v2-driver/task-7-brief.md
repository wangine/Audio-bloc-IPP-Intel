## Task 7: Loaded-driver qualification and frozen-Core integration

**Files:** produce validation reports, accepted artifact manifests and README instructions; no Stage1 v0002 source edits.

**Interfaces:** use Task5's runner and Task4's exact Provider in an isolated copy of the original Stage1 runtime. Bind separate test configuration/publish/control endpoints. Provider observation is the payload delivered to this unchanged Core. Never use a second reader or treat legacy converted FP64 as raw verification.

- [ ] After authorized deployment, verify exactly one new render endpoint and correct identity/format negotiation; require valid startup/frame0 before calling any mode qualified.
- [ ] Execute acceptance A: all24 Exclusive cases, byte-for-byte from first to last frame, with the actual Core/Provider boundary observed; retain per-case mismatch/loss/duplicate and audit-overflow totals.
- [ ] Execute acceptance B: live continuity/clock, repeated lifecycle/format transitions, supported period bounds and long stress; record nominal versus committed versus delivered counters, actual WaveRT allocation mode, EOS and packet chronology. Keep injected overload separate from zero-loss results.
- [ ] If A/B fail, fix and rerun only affected plus relevant regression tests; never discard startup/tail data or relabel a failing polling path as supported. Model-only tests cannot substitute for these runs.
- [ ] Execute acceptance C only after A/B qualify: TIDAL Shared/Exclusive stereo diagnostics before SRC, format/mode provenance, common-frame RMS/M/S/correlation windows and transition intervals. Do not assert identical TIDAL internal PCM between modes.
- [ ] Record actual unchanged Core/Stage2/Stage3 hashes and observed listening state. Publish the qualified driver/Provider packages and explicit limitations; then begin the separate AUX investigation with a new versioned Stage1 candidate.

## Self-review and execution handoff

Tasks1–3 cover pin/build, strict formats, QPC and ownership; Tasks2–4 cover raw ring,
metadata, counters, cancellation and no conversion; Task5 and Task7 implement the
three acceptance groups; Task6 owns the deployment boundary. Each Review Focus
item has a named test. No AUX repair, new Stage1 DSP or current-driver modification
is hidden in these tasks.

Plan status: approved and executing inline. Tasks1–5 are implemented; Task6 has
an unsigned candidate and offline verification, with explicit installation
authorization pending. Task7 has not started. Source review restricted the
production driver to valid packet-commit allocations; position-only ownership
remains unproven and is refused. No loaded-driver PASS is claimed.
