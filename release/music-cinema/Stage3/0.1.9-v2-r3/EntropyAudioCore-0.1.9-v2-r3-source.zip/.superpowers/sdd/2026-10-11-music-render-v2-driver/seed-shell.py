from pathlib import Path
import re
root=Path('Drivers/EntropyMusicRenderV2')
src=root/'upstream/audio/simpleaudiosample/Source'
out=root/'kernel/shell'
out.mkdir(parents=True,exist_ok=True)
names=['adapter.cpp','basetopo.cpp','common.cpp','mintopo.cpp','minwavert.cpp','minwavert.h','NewDelete.cpp','definitions.h','endpoints.h','common.h','NewDelete.h','basetopo.h','kshelper.h','mintopo.h','hw.h','hw.cpp','kshelper.cpp','speakertopo.h','speakertopo.cpp','speakerwavtable.h','speakertoptable.h','minipairs.h','SimpleAudioSample.rc']
for name in names:
    matches=[p for p in src.rglob('*') if p.is_file() and p.name.lower()==name.lower()]
    assert len(matches)==1,name
    text=matches[0].read_text(encoding='utf-8-sig')
    text='\n'.join(line.rstrip() for line in text.splitlines()).rstrip()+'\n'
    (out/name).write_text(text,encoding='utf-8')

def edit(name,change):
    p=out/name;before=p.read_text();p.write_text(change(before),encoding='utf-8')

def body(text,signature,new):
    start=text.index(signature);a=text.index('{',start);depth=1;b=a+1
    while depth:
        if text[b]=='{':depth+=1
        elif text[b]=='}':depth-=1
        b+=1
    return text[:a]+'{\n'+new+'\n}'+text[b:]

edit('minipairs.h',lambda s:s[:s.index('//\n// Capture miniports.')]+s[s.index('//=============================================================================\n//\n// Render miniport pairs.'):])
edit('minipairs.h',lambda s:re.sub(r'#include "micarray[^\n]+\n','',s))
edit('minipairs.h',lambda s:re.sub(r'PENDPOINT_MINIPAIR  g_CaptureEndpoints\[\] =\s*\{[^}]+\};', 'PENDPOINT_MINIPAIR g_CaptureEndpoints[1] = {NULL};',s).replace('#define g_cCaptureEndpoints (SIZEOF_ARRAY(g_CaptureEndpoints))','#define g_cCaptureEndpoints 0'))
edit('minipairs.h',lambda s:s.replace('L"TopologySpeaker"','L"EntropyMusicTopologyV2"').replace('L"WaveSpeaker"','L"EntropyMusicWaveV2"'))
edit('adapter.cpp',lambda s:body(s,'GetRegistrySettings(','    UNREFERENCED_PARAMETER(RegistryPath);\n    PAGED_CODE();\n    return STATUS_SUCCESS;'))
edit('adapter.cpp',lambda s:s.replace('DWORD g_DisableToneGenerator = 0;', 'DWORD g_DisableToneGenerator = 1;'))
edit('common.cpp',lambda s:re.sub(r'^.*CSaveData::.*\n','',s,flags=re.M))
# Remove now-unassigned check following the removed SaveData initializer.
edit('common.cpp',lambda s:re.sub(r'// Initialize SaveData class\.\s*//\s*(?:if \(!NT_SUCCESS\(ntStatus\)\)\s*\{\s*return ntStatus;\s*\})?', '// No render-file transport exists in this product.\n',s))
edit('definitions.h',lambda s:s.replace('#include "savedata.h"',''))
edit('common.h',lambda s:s.replace('#include "savedata.h"',''))
edit('SimpleAudioSample.rc',lambda s:s.replace('SimpleAudioSample','EntropyMusicRenderV2').replace('Simple Audio Sample','Entropy Music Render V2'))
# Strict negotiation uses the same parser/model as stream creation.
edit('minwavert.cpp',lambda s:s.replace('#include "minwavertstream.h"','#include "minwavertstream.h"\n#include "../PcmCommit.h"'))
edit('minwavert.cpp',lambda s:body(s,'CMiniportWaveRT::IsFormatSupported','    PAGED_CODE();\n    if(_bCapture || _ulPin!=0)return STATUS_NO_MATCH;\n    entropy::music::PcmFormat f{};\n    return ParseMusicFormat(_pDataFormat,f)?STATUS_SUCCESS:STATUS_NO_MATCH;'))
# No advertised topology volume/mute nodes; direct passive connection.
edit('speakertoptable.h',lambda s:s[:s.index('//=============================================================================\nstatic\nPCPROPERTY_ITEM SpeakerPropertiesVolume')]+s[s.index('//=============================================================================\nstatic\nPCPROPERTY_ITEM PropertiesSpeakerTopoFilter'):])
edit('speakertoptable.h',lambda s:s.replace('SIZEOF_ARRAY(SpeakerTopologyNodes),','0,').replace('SpeakerTopologyNodes,','NULL,'))
edit('speakertoptable.h',lambda s:s.replace('//=============================================================================\nstatic\nPCPROPERTY_ITEM PropertiesSpeakerTopoFilter', 'static PCCONNECTION_DESCRIPTOR SpeakerTopoMiniportConnections[] = {\n    {PCFILTER_NODE,KSPIN_TOPO_WAVEOUT_SOURCE,PCFILTER_NODE,KSPIN_TOPO_LINEOUT_DEST}\n};\n\n//=============================================================================\nstatic\nPCPROPERTY_ITEM PropertiesSpeakerTopoFilter'))
# Generate only the explicit twelve device formats. Device default PCM16/48k.
def formats(s):
    a=s.index('static\nKSDATAFORMAT_WAVEFORMATEXTENSIBLE');b=s.index('//\n// Supported modes',a)
    entries=[]
    for rate in [48000,44100,88200,96000,176400,192000]:
        for bits,valid in [(16,16),(32,24)]:
            align=bits//4
            entries.append('    {{sizeof(KSDATAFORMAT_WAVEFORMATEXTENSIBLE),0,0,0,STATICGUIDOF(KSDATAFORMAT_TYPE_AUDIO),STATICGUIDOF(KSDATAFORMAT_SUBTYPE_PCM),STATICGUIDOF(KSDATAFORMAT_SPECIFIER_WAVEFORMATEX)},\n     {{WAVE_FORMAT_EXTENSIBLE,2,%d,%d,%d,%d,sizeof(WAVEFORMATEXTENSIBLE)-sizeof(WAVEFORMATEX)},%d,KSAUDIO_SPEAKER_STEREO,STATICGUIDOF(KSDATAFORMAT_SUBTYPE_PCM)}}'%(rate,rate*align,align,bits,valid))
    s=s[:a]+'static KSDATAFORMAT_WAVEFORMATEXTENSIBLE SpeakerHostPinSupportedDeviceFormats[] = {\n'+',\n'.join(entries)+'\n};\n\n'+s[b:]
    s=s.replace('SPEAKER_HOST_MAX_BITS_PER_SAMPLE            16','SPEAKER_HOST_MAX_BITS_PER_SAMPLE            32').replace('SPEAKER_HOST_MIN_SAMPLE_RATE                48000','SPEAKER_HOST_MIN_SAMPLE_RATE                44100').replace('SPEAKER_HOST_MAX_SAMPLE_RATE                48000','SPEAKER_HOST_MAX_SAMPLE_RATE                192000')
    s=s.replace('// To keep the code simple assume device supports only 48KHz, 16-bit, stereo (PCM and NON-PCM)','// Strict stereo PCM16/16 and PCM24/32 at six rates; model validates proposals.')
    s=s.replace('STATIC_AUDIO_SIGNALPROCESSINGMODE_DEFAULT,\n        &SpeakerHostPinSupportedDeviceFormats[0].DataFormat  // 48KHz','STATIC_AUDIO_SIGNALPROCESSINGMODE_DEFAULT,\n        &SpeakerHostPinSupportedDeviceFormats[0].DataFormat')
    return s
edit('speakerwavtable.h',formats)
