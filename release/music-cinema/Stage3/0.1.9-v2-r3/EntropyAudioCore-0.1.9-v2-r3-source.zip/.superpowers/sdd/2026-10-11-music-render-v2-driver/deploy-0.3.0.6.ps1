﻿$ErrorActionPreference='Stop'
$repo='D:\Projects\3Stage-3\Audio-bloc-IPP-Intel'
$package=Join-Path $repo 'release\EntropyMusicRenderV2\0.3.0.6-signed-dev'
$evidence=Join-Path $repo 'validation\music-render-v2'
$status=Join-Path $evidence 'deployment-0.3.0.6-status.json'
function State($phase,$detail){@{phase=$phase;detail=$detail;utc=[datetime]::UtcNow.ToString('o')} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $status -Encoding UTF8}
try {
    State 'STARTED' 'Explicit user approval: sign existing certificate, install only ROOT\EntropyMusicRenderV2, run isolated tests.'
    $principal=[Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
    if(!$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Elevation is required for private key and root device installation'}
    $thumb='89EE6700145A65ED29B0B129052933D17560AFB3'
    $cert=Get-Item -LiteralPath ('Cert:\LocalMachine\My\'+$thumb)
    if(!$cert.HasPrivateKey -or $cert.NotAfter -lt [datetime]::Now){throw 'Existing approved certificate is unavailable'}
    foreach($store in @('Root','TrustedPublisher')){if(!(Test-Path -LiteralPath ('Cert:\LocalMachine\'+$store+'\'+$thumb))){throw 'Existing trust is missing; no automatic certificate import'}}
    Add-Type @'
using System;using System.Runtime.InteropServices;
public static class MusicV2Policy {
 [StructLayout(LayoutKind.Sequential)] public struct Info {public uint Length;public uint Options;}
 [DllImport("ntdll.dll")] public static extern int NtQuerySystemInformation(int c,ref Info i,int size,out int got);
}
'@
    $ci=New-Object MusicV2Policy+Info;$ci.Length=8;$got=0
    $nt=[MusicV2Policy]::NtQuerySystemInformation(103,[ref]$ci,8,[ref]$got)
    if($nt -ne 0 -or !($ci.Options -band 2)){throw 'Existing TESTSIGNING is not confirmed; no boot changes authorized'}
    $existing=@(Get-CimInstance Win32_PnPEntity | Where-Object {$_.HardwareID -contains 'ROOT\EntropyMusicRenderV2'})
    if($existing.Count -ne 1 -or $existing[0].PNPDeviceID -ne 'ROOT\MEDIA\0003'){throw 'Expected sole new-driver instance absent; no broad update'}
    $old=Get-CimInstance Win32_SystemDriver -Filter "Name='EntropyMusicRenderV2'"
    if(!$old -or $old.State -ne 'Running' -or (Get-FileHash -LiteralPath $old.PathName.Trim('"')).Hash -ne '8B70319189A2A3954E89BBD280FDCEAFB5D35182104342AF9DC90FFC3CE6E352'){throw 'Unexpected current new-driver version'}
    $bin=Join-Path $repo 'Drivers\EntropyMusicRenderV2\build\kits\sdk\bin\10.0.28000.0'
    $sign=Join-Path $bin 'x64\signtool.exe';$catTool=Join-Path $bin 'x86\Inf2Cat.exe'
    $driver=Join-Path $package 'driver';$sys=Join-Path $driver 'EntropyMusicRenderV2.sys';$cat=Join-Path $driver 'EntropyMusicRenderV2.cat'
    $unsigned=Join-Path $repo 'release\EntropyMusicRenderV2\0.3.0.6-candidate\driver\EntropyMusicRenderV2.sys'
    if((Get-FileHash -LiteralPath $unsigned).Hash -ne 'F6DED14CED5E66F9FE251DB7FE0E17C5B3D588552AE2B4A336C5CCCD047E3C2A'){throw 'Unsigned reference differs from approved candidate'}
    $alreadySigned=(Get-AuthenticodeSignature -LiteralPath $sys).Status -eq 'Valid'
    if($alreadySigned){
        if((Get-AuthenticodeSignature -LiteralPath $sys).SignerCertificate.Thumbprint -ne $thumb){throw 'Wrong existing signer'}
        $a=[IO.File]::ReadAllBytes($unsigned);$b=[IO.File]::ReadAllBytes($sys);$pe=[BitConverter]::ToUInt32($a,0x3c)
        $checksum=$pe+24+64;$directory=$pe+24+112+32
        if([BitConverter]::ToUInt16($a,$pe+24) -ne 0x20b -or $b.Length -lt $a.Length -or [BitConverter]::ToUInt32($b,$directory) -ne $a.Length){throw 'Unexpected signed PE layout'}
        for($i=0;$i -lt $a.Length;$i++){if(($i -ge $checksum -and $i -lt $checksum+4) -or ($i -ge $directory -and $i -lt $directory+8)){continue};if($a[$i] -ne $b[$i]){throw 'Signed SYS code differs from approved unsigned candidate'}}
    } elseif((Get-FileHash -LiteralPath $sys).Hash -ne (Get-FileHash -LiteralPath $unsigned).Hash){throw 'Unsigned SYS differs from approved candidate'}
    State 'SIGNING_SYS' $thumb
    if(!$alreadySigned){& $sign sign /v /sm /s My /sha1 $thumb /fd SHA256 $sys *> (Join-Path $package 'provenance\sign-sys.log');if($LASTEXITCODE){throw 'Elevated SYS signing failed'}}
    # Catalog membership must be generated AFTER embedding the SYS signature.
    & $catTool "/driver:$driver" '/os:10_CO_X64,10_NI_X64,10_GE_X64' *> (Join-Path $package 'provenance\catalog-generation.log')
    if($LASTEXITCODE){throw 'Signed SYS catalog regeneration failed'}
    & $sign sign /v /sm /s My /sha1 $thumb /fd SHA256 $cat *> (Join-Path $package 'provenance\sign-cat.log')
    if($LASTEXITCODE){throw 'Catalog signing failed'}
    & $sign verify /pa /v $sys *> (Join-Path $package 'provenance\sys-test-signature.log');if($LASTEXITCODE){throw 'Embedded SYS test signature invalid'}
    & $sign verify /pa /v /c $cat $sys *> (Join-Path $package 'provenance\catalog-test-signature.log');if($LASTEXITCODE){throw 'Signed catalog membership invalid'}
    $ErrorActionPreference='Continue'
    & $sign verify /kp /v /c $cat $sys *> (Join-Path $package 'provenance\kernel-signature.log');$kernelVerify=$LASTEXITCODE
    $ErrorActionPreference='Stop'
    foreach($file in @($sys,$cat)){$signature=Get-AuthenticodeSignature -LiteralPath $file;if($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Thumbprint -ne $thumb){throw 'Unexpected signer or invalid test signature'}}
    @{
      authorization='Explicit human reply: Da, semneaza, instaleaza si testeaza';certificateThumbprint=$thumb;
      testSigningAlreadyEnabled=$true;codeIntegrityOptions=$ci.Options;trustChanges=$false;bootChanges=$false;
      embeddedTestSignature='Valid';catalogMembership='Valid';kernelReleasePolicyVerificationExit=$kernelVerify;
      signingDocumentation='https://learn.microsoft.com/en-us/windows-hardware/drivers/install/verifying-the-test-signature'
    } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $package 'provenance\development-signing.json') -Encoding UTF8
    $readme=Get-Content -LiteralPath (Join-Path $package 'README.md') -Raw
    "# Signed development copy — 2026-10-11`r`n`r`nSYS and CAT have valid development test signatures using the existing approved certificate. Live acceptance NOT_RUN. Source archive preserves the unsigned source candidate. No trust/boot policy changed.`r`n`r`n"+$readme | Set-Content -LiteralPath (Join-Path $package 'README.md') -Encoding UTF8
    $deployment=Get-Content -LiteralPath (Join-Path $package 'DEPLOYMENT.md') -Raw
    "# Approved development deployment — 2026-10-11`r`n`r`nUser explicitly approved existing-certificate signing and ONLY ROOT\EntropyMusicRenderV2 installation plus isolated tests. SYS/CAT signatures are Valid under test-signature Authenticode policy. The unsigned candidate documentation below is historical; no production/live certification is implied.`r`n`r`n"+$deployment | Set-Content -LiteralPath (Join-Path $package 'DEPLOYMENT.md') -Encoding UTF8
    $manifest=Get-Content -LiteralPath (Join-Path $package 'manifest.json') -Raw | ConvertFrom-Json
    $manifest.version='0.3.0.6-signed-dev';$manifest.kernelSignatureVerificationExit=$kernelVerify
    $manifest | Add-Member -NotePropertyName developmentSigning -NotePropertyValue @{thumbprint=$thumb;testSignatureVerificationExit=0;catalogMembershipVerificationExit=0;testSigningAlreadyEnabled=$true;bootChanges=$false;trustChanges=$false}
    foreach($item in $manifest.signatures.PSObject.Properties){$item.Value=(Get-AuthenticodeSignature -LiteralPath (Join-Path $package $item.Name)).Status.ToString()}
    $manifest.artifacts=@(Get-ChildItem -LiteralPath $package -Recurse -File | Where-Object {$_.Name -notin @('manifest.json','SHA256SUMS.txt')} | Sort-Object FullName | ForEach-Object {
        @{path=$_.FullName.Substring($package.Length+1).Replace('\','/');bytes=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName).Hash}
    })
    $manifest | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $package 'manifest.json') -Encoding UTF8
    $manifest.artifacts | ForEach-Object {"$($_.sha256)  $($_.path)"} | Set-Content -LiteralPath (Join-Path $package 'SHA256SUMS.txt') -Encoding ASCII
    . (Join-Path $package 'tools\Assert-Package.ps1');$null=Assert-MusicPackage $package
    State 'INSTALLING' 'Signed package verified. Exact new hardware ID only, no restart/default/source changes.'
    $devcon='C:\Program Files (x86)\Windows Kits\10\Tools\10.0.28000.0\x64\devcon.exe'
    & $devcon update (Join-Path $driver 'EntropyMusicRenderV2.inf') 'ROOT\EntropyMusicRenderV2' *> (Join-Path $evidence 'devcon-update-0.3.0.6.log')
    $installExit=$LASTEXITCODE
    if($installExit -ne 0){throw "Exact devcon install exit=$installExit; no automatic reboot/retry"}
    $service=Get-CimInstance Win32_SystemDriver -Filter "Name='EntropyMusicRenderV2'"
    $devices=@(Get-CimInstance Win32_PnPEntity | Where-Object {$_.HardwareID -contains 'ROOT\EntropyMusicRenderV2'})
    @{service=$service | Select-Object Name,State,PathName;devices=$devices | Select-Object Name,PNPDeviceID,Service,ConfigManagerErrorCode;installExit=$installExit;signedSysSha256=(Get-FileHash -LiteralPath $sys).Hash} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $evidence 'installed-driver-0.3.0.6.json') -Encoding UTF8
    if($devices.Count -ne 1 -or $devices[0].ConfigManagerErrorCode -ne 0 -or !$service -or $service.State -ne 'Running'){throw 'Installed driver has not passed exact identity/health checks'}
    State 'INSTALLED' 'Exactly one new root device, problemCode0 and serviceRunning; live acceptance not yet run.'
} catch {State 'FAILED' $_.Exception.Message;exit 1}







