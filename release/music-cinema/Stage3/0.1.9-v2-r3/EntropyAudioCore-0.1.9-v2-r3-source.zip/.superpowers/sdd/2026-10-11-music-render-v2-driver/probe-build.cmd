@echo off
call "C:/Program Files/Microsoft Visual Studio/18/Community/VC/Auxiliary/Build/vcvars64.bat" > nul
cl /nologo /EHsc /std:c++20 /DUNICODE /D_UNICODE /W4 /WX "endpoint-probe.cpp" /Fe:endpoint-probe.exe /link setupapi.lib cfgmgr32.lib ole32.lib uuid.lib
