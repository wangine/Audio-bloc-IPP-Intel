import pathlib,struct
b=pathlib.Path('Drivers/EntropyMusicRenderV2/build/live/installed-0.3.0.6-first-call/44100-16-event/core-raw.bin').read_bytes()
size=struct.unpack_from('<I',b,12)[0]
print('first payload bytes',b[32+160:32+176].hex(),'allzero',not any(b[192:32+size]))
