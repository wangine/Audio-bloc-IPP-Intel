## Task 6: Reproducible package and explicit deployment boundary

**Files:** implement `tools/Build-Provider.ps1`, `Package-Driver.ps1`, extend `tests/PackageTests.py`, create package README, SHA256 manifest and deployment checklist.

**Interfaces:** `Package-Driver.ps1 -Output <isolated-directory>` packages SYS/INF/CAT and Provider/harness with complete source/import provenance. It reports signature/catalog validity; it does not change certificate stores or install devices.

- [ ] Write `PackageHasOneNewStereoIdentity`, `AllArtifactsMatchManifest`, `ExistingDriverIdsAbsent` and `NoInstallFromBuild`; confirm failures on incomplete or deliberately altered package fixtures.
- [ ] Implement packaging/signature verification and rollback documentation identifying only the new device/service; do not embed private signing keys or silently change boot security.
- [ ] Build/check all components, run package tests and verify every artifact SHA256; record actual compiler and signing status. Commit the reviewable package/source state.
- [ ] Present the concrete package, hashes, signature status and exact deployment action to the user; obtain explicit installation authorization at this boundary, as required by the approved handoff. Until then, continue only independent offline verification.

