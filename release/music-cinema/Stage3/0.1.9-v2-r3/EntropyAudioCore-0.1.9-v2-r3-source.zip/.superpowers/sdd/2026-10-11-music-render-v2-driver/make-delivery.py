import hashlib,json,pathlib,shutil,zipfile
repo=pathlib.Path('D:/Projects/3Stage-3/Audio-bloc-IPP-Intel')
package=repo/'Drivers/EntropyMusicRenderV2/build/package-reviewed'
release=repo/'release/EntropyMusicRenderV2/0.3.0.1-candidate'
delivery=repo/'Integration/Drivers/EntropyMusicRenderV2/0.3.0.1-candidate'
if release.exists() or delivery.exists(): raise SystemExit('New versioned directories required')
release.parent.mkdir(parents=True,exist_ok=True)
shutil.copytree(package,release)
delivery.mkdir(parents=True)
archive=delivery/'EntropyMusicRenderV2-0.3.0.1-candidate-win-x64.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as output:
    for file in sorted(release.rglob('*')):
        if file.is_file(): output.write(file,file.relative_to(release).as_posix())
with zipfile.ZipFile(archive) as packed:
    if packed.testzip() is not None: raise SystemExit('Archive CRC failure')
    for file in release.rglob('*'):
        if file.is_file() and packed.read(file.relative_to(release).as_posix())!=file.read_bytes(): raise SystemExit('Archive differs')
manifest=json.loads((package/'manifest.json').read_text(encoding='utf-8-sig'))
record={'version':manifest['version'],'sourceRevision':manifest['sourceRevision'],'sourceWorkingTreeDirty':manifest['sourceWorkingTreeDirty'],
        'archive':archive.name,'archiveBytes':archive.stat().st_size,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest().upper(),
        'manifestSha256':hashlib.sha256((package/'manifest.json').read_bytes()).hexdigest().upper(),
        'tests':{'offlineSuitesPassed':11,'packageChecksPassed':9,'archiveCrcAndEveryFile':'PASS'},
        'signing':'SYS/CAT NotSigned; kernel signature verification correctly rejects unsigned catalog',
        'installation':'NOT_INSTALLED','liveAcceptance':'NOT_RUN','localRelease':str(release),
        'kernelSha256':next(x['sha256'] for x in manifest['artifacts'] if x['path']=='driver/EntropyMusicRenderV2.sys')}
(delivery/'delivery.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(package/'manifest.json',delivery/'manifest.json')
(delivery/'SHA256SUMS.txt').write_text(record['archiveSha256']+'  '+archive.name+'\n',encoding='ascii')
(repo/'validation/music-render-v2/delivery.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record,indent=2))
