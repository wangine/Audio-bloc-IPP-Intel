## Task 2: Deterministic format, clock, ownership and ring model

**Files:** create `model/*`, `protocol/PcmBridgeV1.h`, `tests/ModelTests.cpp`, `tests/BridgeTests.cpp` and `tools/Build-Model.ps1`.

**Interfaces:** define `PcmFormat` with the full PCM metadata; `bool validateFormat(const PcmFormat&) noexcept`; `Clock::reset(uint32_t rate,uint64_t frequency,uint64_t generation)`, `start(uint64_t qpc)`, `pause(uint64_t qpc)`, `bool position(uint64_t qpc,uint64_t& frames) const noexcept`. `PacketTimeline::commit(const PacketDescriptor&,const uint8_t*,uint32_t bytes)` returns an explicit accepted/late/duplicate/overrun result. `advance(uint64_t sourceFrame)` marks eligible committed snapshots exactly once; `stop()` terminates the generation. `PcmRing::peek(PacketView&)` returns a stable non-owning view; `consume(uint64_t sequence)` releases only that packet. Memory spans are supplied at prepare and bounded by the spec.

- [ ] Write `FormatRejectsUnsupported` for the exact twelve formats, bad GUID/mask/align/rate/reserved fields, Float32/PCM32/packed24 and overflow lengths.
- [ ] Write `ClockFractionalRatesAndPause`: 44100 frames after one QPC second, no movement during PAUSE, no cumulative rounding across small updates, checked overflow and unchanged results across repeated position queries.
- [ ] Write `PrefillSurvivesRun`: frame0 committed before RUN is retained, not readable early, readable once when transferred; duplicate commit/query never republishes.
- [ ] Write `RingWrapAndLateReader`: verify the last frame across wrap, fixed descriptor/payload limits, explicit overflow loss, nonzero firstSourceFrame for late attachment and preserved terminated-generation/lifetime totals.
- [ ] Write `StopRestartAndPartialEos`: distinguish PAUSE from STOP, reject old-generation data, preserve exact last valid bytes and accept zero-length EOS only as control state. Simulate ULONG packet-number wrap separately from DMA wrap.
- [ ] Run `Build-Model.ps1` and `ctest --test-dir Drivers/EntropyMusicRenderV2/build/model --output-on-failure`; confirm the named assertions fail before implementing the model.
- [ ] Implement the exact integer QPC model, immutable snapshot lifecycle and bounded ring; define wire version `0x00010000`, explicit fixed-width fields and compile-time size/offset checks. Add invalid-version, short/oversized payload and insufficient-read-buffer assertions to `BridgeTests`.
- [ ] Run the complete model/bridge suites; require PASS and commit. Model PASS is not kernel acceptance.

