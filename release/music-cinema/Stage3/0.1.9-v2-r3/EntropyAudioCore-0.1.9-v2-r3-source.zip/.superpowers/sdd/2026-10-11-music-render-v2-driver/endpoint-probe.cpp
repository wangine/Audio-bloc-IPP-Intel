#include <windows.h>
#include <setupapi.h>
#include <cfgmgr32.h>
#include <initguid.h>
#include <devpkey.h>
#include <mmdeviceapi.h>
#include <functiondiscoverykeys_devpkey.h>
#include <devicetopology.h>
#include <wrl/client.h>
#include <iostream>
#include <vector>
using Microsoft::WRL::ComPtr;
void value(IPropertyStore* store,const PROPERTYKEY& key){PROPVARIANT v{};auto h=store->GetValue(key,&v);std::wcout<<L"hr="<<std::hex<<h<<L" vt="<<std::dec<<v.vt;if(v.vt==VT_LPWSTR && v.pwszVal)std::wcout<<L" "<<v.pwszVal;if(v.vt==VT_CLSID && v.puuid){wchar_t text[40];StringFromGUID2(*v.puuid,text,40);std::wcout<<L" "<<text;}PropVariantClear(&v);}
int wmain(){CoInitializeEx(nullptr,COINIT_MULTITHREADED);GUID g{0xab93289e,0x2692,0x47a9,{0xbc,0x47,0xed,0x17,0x11,0xf6,0xe4,0x30}};auto set=SetupDiGetClassDevsW(&g,nullptr,nullptr,DIGCF_DEVICEINTERFACE|DIGCF_PRESENT);unsigned found=0;
for(DWORD i=0;;++i){SP_DEVICE_INTERFACE_DATA iface{sizeof(iface)};if(!SetupDiEnumDeviceInterfaces(set,nullptr,&g,i,&iface))break;DWORD size=0;SetupDiGetDeviceInterfaceDetailW(set,&iface,nullptr,0,&size,nullptr);std::vector<BYTE> bytes(size);auto detail=reinterpret_cast<SP_DEVICE_INTERFACE_DETAIL_DATA_W*>(bytes.data());detail->cbSize=sizeof(*detail);SP_DEVINFO_DATA data{sizeof(data)};if(!SetupDiGetDeviceInterfaceDetailW(set,&iface,detail,size,nullptr,&data))continue;++found;wchar_t instance[MAX_DEVICE_ID_LEN]{};CM_Get_Device_IDW(data.DevInst,instance,MAX_DEVICE_ID_LEN,0);std::wcout<<L"PRIVATE "<<instance<<L" "<<detail->DevicePath<<L"\n";}SetupDiDestroyDeviceInfoList(set);std::wcout<<L"PRIVATE_COUNT "<<found<<L"\n";
ComPtr<IMMDeviceEnumerator> enumerator;ComPtr<IMMDeviceCollection> devices;auto h=CoCreateInstance(__uuidof(MMDeviceEnumerator),nullptr,CLSCTX_ALL,IID_PPV_ARGS(&enumerator));if(FAILED(h))return 1;enumerator->EnumAudioEndpoints(eRender,DEVICE_STATEMASK_ALL,&devices);UINT n=0;devices->GetCount(&n);
for(UINT i=0;i<n;++i){ComPtr<IMMDevice> device;devices->Item(i,&device);DWORD state=0;device->GetState(&state);LPWSTR id=nullptr;device->GetId(&id);std::wcout<<L"ENDPOINT "<<state<<L" "<<id<<L"\n";CoTaskMemFree(id);ComPtr<IPropertyStore> props;device->OpenPropertyStore(STGM_READ,&props);std::wcout<<L"  NAME ";value(props.Get(),PKEY_Device_FriendlyName);std::wcout<<L"\n  ADAPTER ";value(props.Get(),PKEY_DeviceInterface_FriendlyName);std::wcout<<L"\n  CONTAINER ";value(props.Get(),PKEY_Device_ContainerId);std::wcout<<L"\n";
if(state==DEVICE_STATE_ACTIVE){ComPtr<IDeviceTopology> topo;h=device->Activate(__uuidof(IDeviceTopology),CLSCTX_ALL,nullptr,reinterpret_cast<void**>(topo.GetAddressOf()));if(SUCCEEDED(h)){ComPtr<IConnector> connector;h=topo->GetConnector(0,&connector);if(SUCCEEDED(h)){LPWSTR parent=nullptr;h=connector->GetDeviceIdConnectedTo(&parent);std::wcout<<L"  PARENT hr="<<std::hex<<h<<std::dec<<L" "<<(parent?parent:L"null")<<L"\n";ComPtr<IMMDevice> adapter;ComPtr<IPropertyStore> store;if(parent && SUCCEEDED(enumerator->GetDevice(parent,&adapter)) && SUCCEEDED(adapter->OpenPropertyStore(STGM_READ,&store))){std::wcout<<L"  INSTANCE ";value(store.Get(),PKEY_Device_InstanceId);std::wcout<<L"\n";}CoTaskMemFree(parent);}}}}
CoUninitialize();return 0;}
