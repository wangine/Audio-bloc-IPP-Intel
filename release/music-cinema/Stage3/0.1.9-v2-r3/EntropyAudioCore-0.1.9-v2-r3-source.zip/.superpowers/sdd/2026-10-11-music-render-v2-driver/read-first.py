import struct,pathlib
p=pathlib.Path('Drivers/EntropyMusicRenderV2/build/live/installed-0.3.0.4-contract/44100-16-event/core-raw.bin')
b=p.read_bytes();off=0
for i in range(12):
 magic,version,kind,size,overflow,failed=struct.unpack_from('<IIIIQQ',b,off);off+=32
 if kind==2:print('footer',overflow,failed);break
 gen,seq,frame,qpc,freq,loss,frames,flags=struct.unpack_from('<QQQQQQII',b,off+72)
 print(i,'gen',gen,'seq',seq,'frame',frame,'qpc',qpc,'lost',loss,'frames',frames,'flags',flags)
 off+=size
