EntropyAudioCore Stage3 0.1.9-v2-r3 / 32k / Windows x64

This package contains the complete Core and Qt UI runtime for the 32768-frame FIFO variant.
Live-Test.cmd starts DISARMED and enables only this process's explicitly authorized live test.
Physical output still requires a validated profile, checked DAC configuration, and manual ARM in the UI.

Stage1 and Stage2 are independent processes. Start them separately as needed.
If a Stage3 Core or UI is already running, close that session and run this bundle's Stop-AudioCore.cmd before switching variants or starting a new session.

Offline package check:
  Cold-Start.cmd -SmokeTest
This uses an isolated endpoint and synthetic input. It opens no DAC.

32k live listening qualification: pending.
64k retains the previously accepted r3 DTS trial; its Core binary hash is unchanged.
See STARTUP-AND-32K.md and VALIDATION-CINEMA.md.
