#include "AudioGraph.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <memory>

namespace entropy::engine {

bool AudioGraph::setOfflineParameter(const char* identifier, double value) {
    if (!prepared_ || !crossover_ || !identifier || !std::isfinite(value)) return false;
    auto* parameter = crossover_->getAPVTS().getParameter(identifier);
    if (!parameter) return false;
    const auto& range = parameter->getNormalisableRange();
    if (value < range.start || value > range.end) return false;
    egressPolicyReady_ = false; // Any parameter mutation invalidates the ARM authority.
    parameter->setValueNotifyingHost(parameter->convertTo0to1(static_cast<float>(value)));
    return true;
}

bool AudioGraph::applyOfflineParameters(bool resetHistories) {
    if (!prepared_ || !crossover_) return false;
    try {
        if (resetHistories) crossover_->prepareToPlay(kSampleRate, static_cast<int>(maximumFrames_));
        else crossover_->serviceUpdates();
        return true;
    } catch (...) { prepared_ = false; return false; }
}

bool AudioGraph::prepare(std::uint32_t maximumFrames) {
    prepared_ = false;
    egressPolicyReady_ = false;
    if (!maximumFrames || maximumFrames > 4096) return false;
    // All object allocation, IPP dispatcher warmup and filter compilation are
    // strictly off the audio thread. Never call prepare while processing.
    try {
        auto candidate = std::make_unique<entropy::standalone::EntropyCrossoverAudioProcessor>();
        crossoverBuffer_.prepare(kOutputChannels, maximumFrames);
        matrixBuffer_.prepare(kOutputChannels, maximumFrames);
        candidate->prepareToPlay(kSampleRate, static_cast<int>(maximumFrames));

        if (!matrix_.prepare(kSampleRate, maximumFrames)) return false;
        EntropyOutputMatrixState routing{};
        routing.struct_size = sizeof(routing);
        routing.generation = 1;
        routing.active_source_mask = 0xffffu;
        routing.enabled_destination_mask = 0xffffu;
        for (std::uint32_t ch = 0; ch < kOutputChannels; ++ch)
            routing.source_destination_mask[ch] = 1u << ch;
        if (matrix_.setState(routing) != ENTROPY_OK) return false;

        if (!headroom_.prepare(kSampleRate, maximumFrames)) return false;
        EntropyHeadroomState safety{};
        safety.struct_size = sizeof(safety);
        safety.revision = 1;
        safety.group_count = 1;
        safety.active_channel_mask = 0xffffu;
        safety.transition_ms = 10.0;
        safety.groups[0].struct_size = sizeof(safety.groups[0]);
        safety.groups[0].bounded = 1;
        for (auto& group : safety.channel_group) group = 0;
        // OFFLINE FIXTURE ONLY. Explicit unity policy, NOT production headroom.
        // The real host must publish a validated ledger and gain policy before ARM.
        if (headroom_.setState(safety) != ENTROPY_OK) return false;
        if (headroom_.setMode(ENTROPY_HEADROOM_MODE_BIT_PERFECT) != ENTROPY_OK)
            return false;

        crossover_ = std::move(candidate);
        maximumFrames_ = maximumFrames;
        completedBlocks_.store(0, std::memory_order_relaxed);
        prepared_ = true;
        return true;
    } catch (...) {
        crossover_.reset();
        maximumFrames_ = 0;
        return false;
    }
}

bool AudioGraph::prepareForEgress(std::uint32_t maximumFrames,
                                 const EntropyHeadroomState& ledger, double attenuationDb) {
    if (!std::isfinite(attenuationDb) || attenuationDb < 6.0 || attenuationDb > 120.0)
        return false;
    if (!prepare(maximumFrames)) return false;
    return applyEgressHeadroomPolicy(ledger, attenuationDb);
}

bool AudioGraph::applyEgressHeadroomPolicy(const EntropyHeadroomState& ledger,
                                         double attenuationDb) {
    egressPolicyReady_ = false;
    if (!prepared_ || !std::isfinite(attenuationDb) || attenuationDb < 6.0 || attenuationDb > 120.0)
        return false;
    if (headroom_.setState(ledger) != ENTROPY_OK ||
        headroom_.setPolicy(ENTROPY_HEADROOM_MODE_MANUAL_SAFE, attenuationDb) != ENTROPY_OK) {
        prepared_ = false; return false;
    }
    egressPolicyReady_ = true;
    return true;
}

EntropyResult AudioGraph::process(const double* const* input13, double* const* output16,
                                  std::uint32_t frames) {
    if (!prepared_ || !crossover_) return ENTROPY_ERROR_NOT_PREPARED;
    if (frames > maximumFrames_ || !input13 || !output16)
        return ENTROPY_ERROR_INVALID_ARGUMENT;
    if (frames == 0) return ENTROPY_OK;

    // Reject bad pointers and source data BEFORE advancing any DSP state.
    for (std::uint32_t ch = 0; ch < kInputChannels; ++ch) {
        if (!input13[ch]) return ENTROPY_ERROR_INVALID_ARGUMENT;
        for (std::uint32_t i = 0; i < frames; ++i)
            if (!std::isfinite(input13[ch][i])) return ENTROPY_ERROR_PROCESSING;
    }
    for (std::uint32_t ch = 0; ch < kOutputChannels; ++ch)
        if (!output16[ch]) return ENTROPY_ERROR_INVALID_ARGUMENT;

    for (std::uint32_t ch = 0; ch < kInputChannels; ++ch)
        std::copy_n(input13[ch], frames, crossoverBuffer_.channel(ch));
    for (std::uint32_t ch = kInputChannels; ch < kOutputChannels; ++ch)
        std::fill_n(crossoverBuffer_.channel(ch), frames, 0.0);

    // In-place 16-channel native Crossover input/output view; no JUCE, no heap.
    entropy::native::AudioBuffer<double> view(
        crossoverBuffer_.writePointers(), static_cast<int>(kOutputChannels),
        static_cast<int>(frames));
    entropy::native::MidiBuffer midi;
    crossover_->processBlock(view, midi);

    EntropyAudioBlockF64 block{};
    block.struct_size = sizeof(block);
    block.input_channels = kOutputChannels;
    block.output_channels = kOutputChannels;
    block.frames = frames;
    block.inputs = crossoverBuffer_.readPointers();
    block.outputs = matrixBuffer_.writePointers();
    auto result = matrix_.process(block);
    if (result != ENTROPY_OK) return result;

    // The original Stage3 analyzer observes Matrix FP64 before the gain actuator.
    if (musicAnalysis_ && crossover_->programBlockState().program == 0) {
        EntropyHeadroomAnalysisBlockF64 analysis{};
        analysis.struct_size=sizeof(analysis);analysis.channels=kOutputChannels;
        analysis.frames=frames;analysis.inputs=matrixBuffer_.readPointers();
        result=headroom_.analyzeFinal(analysis);if(result!=ENTROPY_OK)return result;
    }
    block.inputs = matrixBuffer_.readPointers();
    block.outputs = output16;
    result = headroom_.process(block);
    if (result == ENTROPY_OK)
        completedBlocks_.fetch_add(1, std::memory_order_relaxed);
    return result;
}

}
