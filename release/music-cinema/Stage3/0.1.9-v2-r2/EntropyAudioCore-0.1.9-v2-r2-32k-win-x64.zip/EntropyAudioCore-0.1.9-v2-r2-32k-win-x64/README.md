Local Stage3 source-wait candidate 0.1.9-v2-r2

ARM retained during source absence: MUTE / WAITING INPUT indefinitely. DAC owners stop/close; no fabricated Graph/source PCM. Fresh validated input resumes the same Core with native preroll. Explicit DISARM cancels resume. Fatal faults invalidate queued ARM.

Full native results: 56/57 per variant. Inherited Stage04Offline failure retained. Live verification initially PENDING. Original DSP/gain/clock-controller algorithms unchanged. Real Cinema decoder pending.

Launch Live-Test.cmd for the authorized local test; explicit ARM required. Accepted releases and profiles preserved. No Git upload.
