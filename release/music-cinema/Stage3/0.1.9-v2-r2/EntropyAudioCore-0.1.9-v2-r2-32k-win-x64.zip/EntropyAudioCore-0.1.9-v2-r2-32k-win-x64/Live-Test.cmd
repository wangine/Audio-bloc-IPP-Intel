@echo off
call "%~dp0Cold-Start.cmd" -AuthorizedLiveTest %*
exit /b %ERRORLEVEL%
