# Stage1 MUSIC v0003-r9 — candidat local

Rectifică rezerva de pornire MUSIC RAW. AUX legacy, PCM decode, SRC, Matrix, providerul RAW și kernelul rămân neschimbate.

Cele 19 teste native și capturile live Shared 16/48 și Exclusive 16/44,1 trec. Vezi `docs/R9-RAW-STARTUP-HANDOFF.md` pentru dovezi și limite.

`Start-Stage1-Music.cmd` pornește Core și UI; `ColdStart-Stage1-Music.cmd` restartează Core; `Stop-Stage1-Music.cmd` îl oprește normal. r8 rămâne separat pentru referință. Ordinea Stage1/2/3 este independentă.
