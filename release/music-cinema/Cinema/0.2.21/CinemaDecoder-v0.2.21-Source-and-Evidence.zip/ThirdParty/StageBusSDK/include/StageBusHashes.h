#pragma once
#include <stdint.h>
#include "MusicStageBusHashes.h"
#include "CinemaStageBusHashes.h"
inline constexpr uint8_t contractHash[32] = {20,  40,  249, 206, 109, 110, 229, 251, 0,   202, 50,
                                             15,  148, 54,  220, 131, 25,  146, 237, 240, 73,  145,
                                             217, 197, 69,  150, 185, 100, 110, 41,  110, 203};
inline constexpr uint8_t layoutHash10[32] = {170, 247, 229, 210, 246, 155, 208, 186, 138, 245, 245,
                                             64,  242, 20,  10,  106, 95,  34,  225, 79,  121, 40,
                                             59,  238, 57,  197, 240, 237, 243, 130, 143, 134};
inline constexpr uint8_t layoutHash11[32] = {136, 37,  186, 45,  191, 67,  232, 127, 118, 246, 116,
                                             60,  23,  246, 222, 81,  163, 119, 149, 70,  170, 100,
                                             207, 137, 243, 126, 68,  63,  234, 37,  219, 43};
